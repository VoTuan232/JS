//
//	librarian_setting.js
//
//	Copyright 2017 Roland Corporation. All rights reserved.
//


function LibrarianSetting1() { /* Performance */

	this.rows = 128;

	this.blockSet = [];
	(function(blockSet) {
		blockSet.push('UsrPerform%PerformCommon');
		blockSet.push('UsrPerform%PerformCommonMFX1');
		blockSet.push('UsrPerform%PerformCommonChorus');
		blockSet.push('UsrPerform%PerformCommonReverb');
		blockSet.push('UsrPerform%PerformCommonMFX2');
		blockSet.push('UsrPerform%PerformCommonMFX3');
		blockSet.push('UsrPerform%PerformController');
		for (var part = 1; part <= 16; part++) {
			blockSet.push('UsrPerform%PerformMIDI(' + part + ')');
		}
		for (var part = 1; part <= 16; part++) {
			blockSet.push('UsrPerform%PerformPart(' + part + ')');
		}
		for (var part = 1; part <= 16; part++) {
			blockSet.push('UsrPerform%PerformZone(' + part + ')');
		}
	})(this.blockSet);

	this.temporarySet = {};
	(function(blockSet, temporarySet) {
		for (var n = 0, max = blockSet.length; n < max; n++) {
			temporarySet[blockSet[n]] = blockSet[n].replace(/UsrPerform%/g, 'TemporaryPerformance%');
		}
	})(this.blockSet, this.temporarySet);

	this.columnInfo = [
		{ type: 'text12', width: '12' }
	];

	this.value = function(paramSet, column) {
		var text = '';
		var data = paramSet['UsrPerform%PerformCommon'];
		for (var i = 0; i < 12; i++) {
			text += String.fromCharCode(parseInt(data[i], 16));
		}
		return text;
	}

	this.setValue = function(paramSet, column, value) {
		var data = paramSet['UsrPerform%PerformCommon'];
		for (var i = 0; i < 12; i++) {
			var code = (i < value.length) ? value.charCodeAt(i) : 32;
			if (code < 32 || code > 127) code = 32;
			data[i] = code.toString(16);
		}
	}

	this.readStart = function(midi) {}
	this.readStop = function(midi) {}
	this.writeStart = function(midi) {}
	this.writeCommand = function(midi) {
		midi.send('F04110' + ProductSetting.modelId + '120F001001015FF7');
	}
	this.writeStop = function(midi) {}
	this.writeTemporaryStart = function(midi, row) {}
	this.writeTemporaryStop = function(midi) {}
	this.previewStart = function(midi) {}
	this.previewStop = function(midi) {}


}

function LibrarianSetting2() { /* Patch */

	this.rows = 256;

	this.blockSet = [
		'UsrPatch%PatchCommon',
		'UsrPatch%PatchCommonMFX',
		'UsrPatch%PatchCommonChorus',
		'UsrPatch%PatchCommonReverb',
		'UsrPatch%PatchTMT',
		'UsrPatch%PatchTone(1)',
		'UsrPatch%PatchTone(2)',
		'UsrPatch%PatchTone(3)',
		'UsrPatch%PatchTone(4)'
	];

	this.temporarySet = {};
	(function(blockSet, temporarySet) {
		for (var n = 0, max = blockSet.length; n < max; n++) {
			temporarySet[blockSet[n]] = blockSet[n].replace(/UsrPatch%/g, 'TemporaryPatch/DrumPatch(1)%TemporaryPatch%');
		}
	})(this.blockSet, this.temporarySet);

	this.columnInfo = [
		{ type: 'text12', width: '12' },
		{ type: 'selectbox', options: [
			"---", "PNO", "EP ", "KEY", "BEL", "MLT", "ORG", "ACD",
			"HRM", "AGT", "EGT", "DGT", "BS", "SBS", "STR", "ORC",
			"HIT", "WND", "FLT", "BRS", "SBR", "SAX", "HLD", "SLD",
			"TEK", "PLS", "FX ", "SYN", "BPD", "SPD", "VOX", "PLK",
			"ETH", "FRT", "PRC", "SFX", "BTS", "DRM", "CMB", "SMP" ] }
	];

	this.value = function(paramSet, column) {
		if (column == 0) {
			var text = '';
			var data = paramSet['UsrPatch%PatchCommon'];
			for (var i = 0; i < 12; i++) {
				text += String.fromCharCode(parseInt(data[i], 16));
			}
			return text;
		}
		if (column == 1) {
			var data = paramSet['UsrPatch%PatchCommon'];
			var cate = parseInt(data[12], 16);
			return cate;
		}
	}

	this.setValue = function(paramSet, column, value) {
		if (column == 0) {
			var data = paramSet['UsrPatch%PatchCommon'];
			for (var i = 0; i < 12; i++) {
				var code = (i < value.length) ? value.charCodeAt(i) : 32;
				if (code < 32 || code > 127) code = 32;
				data[i] = code.toString(16);
			}
		}
		if (column == 1) {
			var data = paramSet['UsrPatch%PatchCommon'];
			var cate = hex2(parseInt(value, 10));
			data[12] = cate;
		}
	}

	this.readStart = function(midi) {}
	this.readStop = function(midi) {}
	this.writeStart = function(midi) {}
	this.writeCommand = function(midi) {
		midi.send('F04110' + ProductSetting.modelId + '120F001001015FF7');
	}
	this.writeStop = function(midi) {}
	this.writeTemporaryStart = function(midi, row) {
		midi.send('F04110' + ProductSetting.modelId + '120F0020000051F7');
		midi.send('F04110' + ProductSetting.modelId + '1201000000007FF7');
		midi.send('F04110' + ProductSetting.modelId + '120100000457000024F7');
	}
	this.writeTemporaryStop = function(midi) {}
	this.previewStart = function(midi) {
		midi.send('F04110' + ProductSetting.modelId + '120F0020000150F7');
	}
	this.previewStop = function(midi) {
		midi.send('F04110' + ProductSetting.modelId + '120F0020000051F7');
	}
}

function LibrarianSetting3() { /* Drum Kit */

	this.rows = 8;

	this.blockSet = [];
	(function(blockSet) {
		blockSet.push('UsrDrum%DrumCommon');
		blockSet.push('UsrDrum%DrumCommonMFX');
		blockSet.push('UsrDrum%DrumCommonChorus');
		blockSet.push('UsrDrum%DrumCommonReverb');
		for (var key = 21; key <= 108; key++) {
			blockSet.push('UsrDrum%DrumTone(#' + key + ')');
		}
	})(this.blockSet);

	this.temporarySet = {};
	(function(blockSet, temporarySet) {
		for (var n = 0, max = blockSet.length; n < max; n++) {
			temporarySet[blockSet[n]] = blockSet[n].replace(/UsrDrum%/g, 'TemporaryPatch/DrumPatch(1)%TemporaryDrum%');
		}
	})(this.blockSet, this.temporarySet);

	this.columnInfo = [
		{ type: 'text12', width: '12'}
	];

	this.value = function(paramSet, column) {
		var text = '';
		var data = paramSet['UsrDrum%DrumCommon'];
		for (var i = 0; i < 12; i++) {
			text += String.fromCharCode(parseInt(data[i], 16));
		}
		return text;
	}

	this.setValue = function(paramSet, column, value) {
		var data = paramSet['UsrDrum%DrumCommon'];
		for (var i = 0; i < 12; i++) {
			var code = (i < value.length) ? value.charCodeAt(i) : 32;
			if (code < 32 || code > 127) code = 32;
			data[i] = code.toString(16);
		}
	}

	this.readStart = function(midi) {}
	this.readStop = function(midi) {}
	this.writeStart = function(midi) {}
	this.writeCommand = function(midi) {
		midi.send('F04110' + ProductSetting.modelId + '120F001001015FF7');
	}
	this.writeStop = function(midi) {}
	this.writeTemporaryStart = function(midi, row) {
		midi.send('F04110' + ProductSetting.modelId + '120F0020000051F7');
		midi.send('F04110' + ProductSetting.modelId + '1201000000007FF7');
		midi.send('F04110' + ProductSetting.modelId + '120100000456000025F7');
	}
	this.writeTemporaryStop = function(midi) {}
	this.previewStart = function(midi) {
		midi.send('F04110' + ProductSetting.modelId + '120F0020000150F7');
	}
	this.previewStop = function(midi) {
		midi.send('F04110' + ProductSetting.modelId + '120F0020000051F7');
	}
}

function LibrarianSetting4() { /* Vocal Effect */

	this.rows = 20;

	this.blockSet = [
		'UsrVfx%Vfx'
	];

	this.temporarySet = {
		'UsrVfx%Vfx': 'TemporaryVfx%Vfx'
	};

	this.columnInfo = [
		{ type: 'text12', width: '12' }
	];

	this.value = function(paramSet, column) {
		var text = '';
		var data = paramSet['UsrVfx%Vfx'];
		for (var i = 0; i < 12; i++) {
			text += String.fromCharCode(parseInt(data[i], 16));
		}
		return text;
	}

	this.setValue = function(paramSet, column, value) {
		var data = paramSet['UsrVfx%Vfx'];
		for (var i = 0; i < 12; i++) {
			var code = (i < value.length) ? value.charCodeAt(i) : 32;
			if (code < 32 || code > 127) code = 32;
			data[i] = code.toString(16);
		}
	}

	this.readStart = function(midi) {}
	this.readStop = function(midi) {}
	this.writeStart = function(midi) {}
	this.writeCommand = function(midi) {
		midi.send('F04110' + ProductSetting.modelId + '120F001001015FF7');
	}
	this.writeStop = function(midi) {}
	this.writeTemporaryStart = function(midi, row) {}
	this.writeTemporaryStop = function(midi) {}
	this.previewStart = function(midi) {}
	this.previewStop = function(midi) {}
}
