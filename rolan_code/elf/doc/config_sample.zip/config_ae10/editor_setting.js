//
//	editor_setting.js
//
//	Copyright 2016 Roland Corporation. All rights reserved.
//

function EditorSetting() {

	this.blockSet = [];
	(function(blockSet){
		blockSet.push('TemporaryStudioSet%StudioSetCommon');
		blockSet.push('TemporaryStudioSet%StudioSetCommonMFX(MFX1)');
		blockSet.push('TemporaryStudioSet%StudioSetCommonChorus');
		blockSet.push('TemporaryStudioSet%StudioSetCommonReverb');
		blockSet.push('TemporaryStudioSet%StudioSetCommonMFX(MFX2)');
		for (var part = 1; part <= 4; part++) {
			blockSet.push('TemporaryStudioSet%StudioSetPart(Part' + part + ')');
		}
	})(this.blockSet);

	this.readStart = function(midi) {}
	this.readStop = function(midi) {}
	this.syncStart = function(midi) {}
	this.syncStop = function(midi) {}
	this.previewStart = function(midi, part) {}
	this.previewStop = function(midi) {}

	this.parts = 0;
}
