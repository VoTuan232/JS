//
//	librarian_setting.js
//
//	Copyright 2016 Roland Corporation. All rights reserved.
//

function SUM(msg) {
	var sum = 0;
	for (var i = 0, len = msg.length; i < len; i += 2) {
		sum += parseInt(msg.substr(i, 2), 16);
	}
	sum = (128 - (sum % 128)) & 0x7f;
	return hex2(sum);
}

var MSB, LSB, PC, _MSB, _LSB, _PC;

function LibrarianSetting1() {

	this.rows = 64;
	this.columnInfo = [
		{ type: 'text16', width: '16' }
	];

	this.blockSet = [];
	(function(blockSet){
		blockSet.push('UserStudioSet%StudioSetCommon');
		blockSet.push('UserStudioSet%StudioSetCommonChorus');
		blockSet.push('UserStudioSet%StudioSetCommonReverb');
		blockSet.push('UserStudioSet%StudioSetCommonRSS');
		blockSet.push('UserStudioSet%StudioSetMasteringEQ');
		for (var part = 1; part <= 16; part++) {
			blockSet.push('UserStudioSet%StudioSetMIDI(Channel' + part + ')');
		}
		for (var part = 1; part <= 16; part++) {
			blockSet.push('UserStudioSet%StudioSetPart(Part' + part + ')');
		}
		for (var part = 1; part <= 16; part++) {
			blockSet.push('UserStudioSet%StudioSetPartEQ(Part' + part + ')');
		}
	})(this.blockSet);

	this.temporarySet = {};

	this.value = function(paramSet, column) {
		var text = '';
		var data = paramSet['UserStudioSet%StudioSetCommon'];
		for (var i = 0; i < 16; i++) {
			text += String.fromCharCode(parseInt(data[i], 16));
		}
		return text;
	}

	this.setValue = function(paramSet, column, value) {
		var data = paramSet['UserStudioSet%StudioSetCommon'];
		for (var i = 0; i < 16; i++) {
			var code = (i < value.length) ? value.charCodeAt(i) : 32;
			if (code < 32 || code > 127) code = 32;
			data[i] = code.toString(16);
		}
	}

	this.readStart = function(midi) {}
	this.readStop = function(midi) {}
	this.writeStart = function(midi) {}
	this.writeCommand = function(midi) {}
	this.writeStop = function(midi) {}
	this.writeTemporaryStart = function(midi, row) {}
	this.writeTemporaryStop = function(midi) {}

	this.previewStart = function(midi) { midi.send('F04110000064120F0020000150F7'); }
	this.previewStop = function(midi)  { midi.send('F04110000064120F0020000051F7'); }
}

function LibrarianSetting2() {

	this.rows = 256;
	this.columnInfo = [
		{ type: 'text12', width: '12' }
	];

	this.blockSet = [];
	(function(blockSet){
		blockSet.push('UserPCMTone%PCMToneCommon');
		blockSet.push('UserPCMTone%PCMToneCommonMFX');
		blockSet.push('UserPCMTone%PCMTonePMT(PartialMixTable)');
		blockSet.push('UserPCMTone%PCMTonePartial(Partial1)');
		blockSet.push('UserPCMTone%PCMTonePartial(Partial2)');
		blockSet.push('UserPCMTone%PCMTonePartial(Partial3)');
		blockSet.push('UserPCMTone%PCMTonePartial(Partial4)');
		blockSet.push('UserPCMTone%PCMToneCommon2');
	})(this.blockSet);

	this.temporarySet = {};
	(function(blockSet, temporarySet){
		for (var n = 0, max = blockSet.length; n < max; n++) {
			temporarySet[blockSet[n]] = blockSet[n].replace(/UserPCMTone%/g, 'TemporaryTonePart(1)%TemporaryPCMTone%');
		}
	})(this.blockSet, this.temporarySet);

	this.value = function(paramSet, column) {
		var text = '';
		var data = paramSet['UserPCMTone%PCMToneCommon'];
		for (var i = 0; i < 12; i++) {
			text += String.fromCharCode(parseInt(data[i], 16));
		}
		return text;
	}

	this.setValue = function(paramSet, column, value) {
		var data = paramSet['UserPCMTone%PCMToneCommon'];
		for (var i = 0; i < 12; i++) {
			var code = (i < value.length) ? value.charCodeAt(i) : 32;
			if (code < 32 || code > 127) code = 32;
			data[i] = code.toString(16);
		}
	}

	this.readStart = function(midi) {}
	this.readStop = function(midi) {}
	this.writeStart = function(midi) {}
	this.writeCommand = function(midi) {}
	this.writeStop = function(midi) {}
	this.writeTemporaryStart = function(midi, row) {
		if (row < 128) {
			MSB = 87; LSB = 0; PC = row;
		} else if (row < 256) {
			MSB = 87; LSB = 1; PC = row - 128;
		}
		_MSB = hex2(MSB); _LSB = hex2(LSB); _PC  = hex2(PC);
		midi.send('F041100000641218002006' + _MSB + SUM('18002006' + _MSB) + 'F7');
		midi.send('F041100000641218002007' + _LSB + SUM('18002007' + _LSB) + 'F7');
		midi.send('F041100000641218002008' + _PC  + SUM('18002008' + _PC ) + 'F7');
	}
	this.writeTemporaryStop = function(midi) {}

	this.previewStart = function(midi) { midi.send('F04110000064120F0020000150F7'); }
	this.previewStop = function(midi)  { midi.send('F04110000064120F0020000051F7'); }
}

function LibrarianSetting3() {

	this.rows = 32;
	this.columnInfo = [
		{ type: 'text12', width: '12' }
	];

	this.blockSet = [];
	(function(blockSet){
		blockSet.push('UserRhythmSet%RhythmSetCommon');
		blockSet.push('UserRhythmSet%RhythmSetCommonMFX');
		blockSet.push('UserRhythmSet%RhythmSetCommonComp/EQ');
		for (var key = 21; key <= 108; key++) {
			blockSet.push('UserRhythmSet%RhythmSetPartial(Key#' + key + ')');
		}
		blockSet.push('UserRhythmSet%RhythmSetCommon2');
	})(this.blockSet);

	this.temporarySet = {};
	(function(blockSet, temporarySet){
		for (var n = 0, max = blockSet.length; n < max; n++) {
			temporarySet[blockSet[n]] = blockSet[n].replace(/UserRhythmSet%/g, 'TemporaryTonePart(1)%TemporaryRhythmSet%');
		}
	})(this.blockSet, this.temporarySet);

	this.value = function(paramSet, column) {
		var text = '';
		var data = paramSet['UserRhythmSet%RhythmSetCommon'];
		for (var i = 0; i < 12; i++) {
			text += String.fromCharCode(parseInt(data[i], 16));
		}
		return text;
	}

	this.setValue = function(paramSet, column, value) {
		var data = paramSet['UserRhythmSet%RhythmSetCommon'];
		for (var i = 0; i < 12; i++) {
			var code = (i < value.length) ? value.charCodeAt(i) : 32;
			if (code < 32 || code > 127) code = 32;
			data[i] = code.toString(16);
		}
	}

	this.readStart = function(midi) {}
	this.readStop = function(midi) {}
	this.writeStart = function(midi) {}
	this.writeCommand = function(midi) {}
	this.writeStop = function(midi) {}
	this.writeTemporaryStart = function(midi, row) {
		MSB = 86; LSB = 0; PC = row;
		_MSB = hex2(MSB); _LSB = hex2(LSB); _PC  = hex2(PC);
		midi.send('F041100000641218002006' + _MSB + SUM('18002006' + _MSB) + 'F7');
		midi.send('F041100000641218002007' + _LSB + SUM('18002007' + _LSB) + 'F7');
		midi.send('F041100000641218002008' + _PC  + SUM('18002008' + _PC ) + 'F7');
	}
	this.writeTemporaryStop = function(midi) {}

	this.previewStart = function(midi) { midi.send('F04110000064120F0020000150F7'); }
	this.previewStop = function(midi)  { midi.send('F04110000064120F0020000051F7'); }
}

function LibrarianSetting4() {

	this.rows = 512;
	this.columnInfo = [
		{ type: 'text12', width: '12' }
	];

	this.blockSet = [];
	(function(blockSet){
			blockSet.push('UserSynthTone%SynthToneCommon');
			blockSet.push('UserSynthTone%SynthToneMFX');
			blockSet.push('UserSynthTone%SynthTonePartial(1)');
			blockSet.push('UserSynthTone%SynthTonePartial(2)');
			blockSet.push('UserSynthTone%SynthTonePartial(3)');
			blockSet.push('UserSynthTone%SynthToneModify');
	})(this.blockSet);

	this.temporarySet = {};
	(function(blockSet, temporarySet){
		for (var n = 0, max = blockSet.length; n < max; n++) {
			temporarySet[blockSet[n]] = blockSet[n].replace(/UserSynthTone%/g, 'TemporaryTonePart(1)%TemporarySynthTone%');
		}
	})(this.blockSet, this.temporarySet);

	this.value = function(paramSet, column) {
		var text = '';
		var data = paramSet['UserSynthTone%SynthToneCommon'];
		for (var i = 0; i < 12; i++) {
			text += String.fromCharCode(parseInt(data[i], 16));
		}
		return text;
	}

	this.setValue = function(paramSet, column, value) {
		var data = paramSet['UserSynthTone%SynthToneCommon'];
		for (var i = 0; i < 12; i++) {
			var code = (i < value.length) ? value.charCodeAt(i) : 32;
			if (code < 32 || code > 127) code = 32;
			data[i] = code.toString(16);
		}
	}

	this.readStart = function(midi) {}
	this.readStop = function(midi) {}
	this.writeStart = function(midi) {}
	this.writeCommand = function(midi) {}
	this.writeStop = function(midi) {}
	this.writeTemporaryStart = function(midi, row) {
		if (row < 128) {
			MSB = 95; LSB = 0; PC = row;
		} else if (row < 256) {
			MSB = 95; LSB = 1; PC = row - 128;
		} else if (row < 384) {
			MSB = 95; LSB = 2; PC = row - 256;
		} else if (row < 512) {
			MSB = 95; LSB = 3; PC = row - 384;
		}
		_MSB = hex2(MSB); _LSB = hex2(LSB); _PC  = hex2(PC);
		midi.send('F041100000641218002006' + _MSB + SUM('18002006' + _MSB) + 'F7');
		midi.send('F041100000641218002007' + _LSB + SUM('18002007' + _LSB) + 'F7');
		midi.send('F041100000641218002008' + _PC  + SUM('18002008' + _PC ) + 'F7');
	}
	this.writeTemporaryStop = function(midi) {}

	this.previewStart = function(midi) { midi.send('F04110000064120F0020000150F7'); }
	this.previewStop = function(midi)  { midi.send('F04110000064120F0020000051F7'); }
}

function LibrarianSetting5() {

	this.rows = 256;
	this.columnInfo = [
		{ type: 'text16', width: '16' }
	];

	this.blockSet = [];
	(function(blockSet){
			blockSet.push('UserSuperNATURALTone%SNToneCommon');
			blockSet.push('UserSuperNATURALTone%SNToneMFX');
	})(this.blockSet);

	this.temporarySet = {};
	(function(blockSet, temporarySet){
		for (var n = 0, max = blockSet.length; n < max; n++) {
			temporarySet[blockSet[n]] = blockSet[n].replace(/UserSuperNATURALTone%/g, 'TemporaryTonePart(1)%TemporarySuperNATURALTone%');
		}
	})(this.blockSet, this.temporarySet);

	this.value = function(paramSet, column) {
		var text = '';
		var data = paramSet['UserSuperNATURALTone%SNToneCommon'];
		for (var i = 0; i < 16; i++) {
			text += String.fromCharCode(parseInt(data[i], 16));
		}
		return text;
	}

	this.setValue = function(paramSet, column, value) {
		var data = paramSet['UserSuperNATURALTone%SNToneCommon'];
		for (var i = 0; i < 16; i++) {
			var code = (i < value.length) ? value.charCodeAt(i) : 32;
			if (code < 32 || code > 127) code = 32;
			data[i] = code.toString(16);
		}
	}

	this.readStart = function(midi) {}
	this.readStop = function(midi) {}
	this.writeStart = function(midi) {}
	this.writeCommand = function(midi) {}
	this.writeStop = function(midi) {}
	this.writeTemporaryStart = function(midi, row) {
		if (row < 128) {
			MSB = 89; LSB = 0; PC = row;
		} else if (row < 256) {
			MSB = 89; LSB = 1; PC = row - 128;
		}
		_MSB = hex2(MSB); _LSB = hex2(LSB); _PC  = hex2(PC);
		midi.send('F041100000641218002006' + _MSB + SUM('18002006' + _MSB) + 'F7');
		midi.send('F041100000641218002007' + _LSB + SUM('18002007' + _LSB) + 'F7');
		midi.send('F041100000641218002008' + _PC  + SUM('18002008' + _PC ) + 'F7');
	}
	this.writeTemporaryStop = function(midi) {}

	this.previewStart = function(midi) { midi.send('F04110000064120F0020000150F7'); }
	this.previewStop = function(midi)  { midi.send('F04110000064120F0020000051F7'); }
}

function LibrarianSetting6() {

	this.rows = 64;
	this.columnInfo = [
		{ type: 'text12', width: '12' }
	];

	this.blockSet = [];
	(function(blockSet){
		blockSet.push('UserDrumKit%DrumKitCommon');
		blockSet.push('UserDrumKit%DrumKitMFX');
		blockSet.push('UserDrumKit%DrumKitCommonComp/EQ');
		for (var key = 27; key <= 88; key++) {
			blockSet.push('UserDrumKit%DrumKitNote(Key#' + key + ')');
		}
	})(this.blockSet);

	this.temporarySet = {};
	(function(blockSet, temporarySet){
		for (var n = 0, max = blockSet.length; n < max; n++) {
			temporarySet[blockSet[n]] = blockSet[n].replace(/UserDrumKit%/g, 'TemporaryTonePart(1)%TemporaryDrumKit%');
		}
	})(this.blockSet, this.temporarySet);

	this.value = function(paramSet, column) {
		var text = '';
		var data = paramSet['UserDrumKit%DrumKitCommon'];
		for (var i = 0; i < 16; i++) {
			text += String.fromCharCode(parseInt(data[i], 16));
		}
		return text;
	}

	this.setValue = function(paramSet, column, value) {
		var data = paramSet['UserDrumKit%DrumKitCommon'];
		for (var i = 0; i < 16; i++) {
			var code = (i < value.length) ? value.charCodeAt(i) : 32;
			if (code < 32 || code > 127) code = 32;
			data[i] = code.toString(16);
		}
	}

	this.readStart = function(midi) {}
	this.readStop = function(midi) {}
	this.writeStart = function(midi) {}
	this.writeCommand = function(midi) {}
	this.writeStop = function(midi) {}
	this.writeTemporaryStart = function(midi, row) {
		MSB = 88; LSB = 0; PC = row;
		_MSB = hex2(MSB); _LSB = hex2(LSB); _PC  = hex2(PC);
		midi.send('F041100000641218002006' + _MSB + SUM('18002006' + _MSB) + 'F7');
		midi.send('F041100000641218002007' + _LSB + SUM('18002007' + _LSB) + 'F7');
		midi.send('F041100000641218002008' + _PC  + SUM('18002008' + _PC ) + 'F7');
	}
	this.writeTemporaryStop = function(midi) {}

	this.previewStart = function(midi) { midi.send('F04110000064120F0020000150F7'); }
	this.previewStop = function(midi)  { midi.send('F04110000064120F0020000051F7'); }
}
