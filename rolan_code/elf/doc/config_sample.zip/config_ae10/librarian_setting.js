//
//	librarian_setting.js
//
//	Copyright 2016 Roland Corporation. All rights reserved.
//

function LibrarianSetting() {

	this.rows = 100;
	this.columnInfo = [
		{ type: 'text16', width: '16' }
	];

	this.blockSet = [];
	(function(blockSet){
		blockSet.push('UserStudioSet%StudioSetCommon');
		blockSet.push('UserStudioSet%StudioSetCommonMFX(MFX1)');
		blockSet.push('UserStudioSet%StudioSetCommonChorus');
		blockSet.push('UserStudioSet%StudioSetCommonReverb');
		blockSet.push('UserStudioSet%StudioSetCommonMFX(MFX2)');
		for (var part = 1; part <= 4; part++) {
			blockSet.push('UserStudioSet%StudioSetPart(Part' + part + ')');
		}
	})(this.blockSet);

	this.temporarySet = {};
	(function(blockSet, temporarySet){
		for (var n = 0, max = blockSet.length; n < max; n++) {
			temporarySet[blockSet[n]] = blockSet[n].replace(/UserStudioSet%/g, 'TemporaryStudioSet%');
		}
	})(this.blockSet, this.temporarySet);

	this.value = function(paramSet, column) {
		var text = '';
		var data = paramSet['UserStudioSet%StudioSetCommon'];
		for (var i = 0; i < 16; i++) {
			text += String.fromCharCode(parseInt(data[i], 16));
		}
		return text;
	}

	this.setValue = function(paramSet, column, value) {
		var data = paramSet['UserStudioSet%StudioSetCommon'];
		for (var i = 0; i < 16; i++) {
			var code = (i < value.length) ? value.charCodeAt(i) : 32;
			if (code < 32 || code > 127) code = 32;
			data[i] = code.toString(16);
		}
	}

	this.readStart = function(midi) {}
	this.readStop = function(midi) {}
	this.writeStart = function(midi) {}
	this.writeCommand = function(midi) {
		midi.send('F041100000002F120F001001015FF7');  /* write command */
	}
	this.writeStop = function(midi) {}
	this.writeTemporaryStart = function(midi, row) {}
	this.writeTemporaryStop = function(midi) {}

	this.previewStart = function(midi) {}
	this.previewStop = function(midi)  {}
}
