//
//	editor_setting.js
//
//	Copyright 2016 Roland Corporation. All rights reserved.
//

function EditorSetting1() {

	this.blockSet = [
		'Setup%Setup',
		'System%SystemCommon'
	];

	this.readStart = function(midi) {}
	this.readStop = function(midi) {}
	this.syncStart = function(midi) {}
	this.syncStop = function(midi) {}
	this.previewStart = function(midi, part) {}
	this.previewStop = function(midi) {}

	this.parts = 0;
}

function EditorSetting2() {

	this.blockSet = [];
	(function(blockSet){
		blockSet.push('TemporaryStudioSet%StudioSetCommon');
		blockSet.push('TemporaryStudioSet%StudioSetCommonChorus');
		blockSet.push('TemporaryStudioSet%StudioSetCommonReverb');
		blockSet.push('TemporaryStudioSet%StudioSetCommonRSS');
		blockSet.push('TemporaryStudioSet%StudioSetMasteringEQ');
		for (var part = 1; part <= 16; part++) {
			blockSet.push('TemporaryStudioSet%StudioSetMIDI(Channel' + part + ')');
			blockSet.push('TemporaryStudioSet%StudioSetPart(Part' + part + ')');
			blockSet.push('TemporaryStudioSet%StudioSetPartEQ(Part' + part + ')');
		}
	})(this.blockSet);

	this.readStart = function(midi) {}
	this.readStop = function(midi) {}
	this.syncStart = function(midi) {}
	this.syncStop = function(midi) {}
	this.previewStart = function(midi, part) {
		var chksum = 51 - (++part);
		midi.send('F04110000064120F002000' + hex2(part) + hex2(chksum) + 'F7');
	}
	this.previewStop = function(midi) { midi.send('F04110000064120F0020000051F7'); }

	this.parts = 16;
	this.partSet = function(part) {

		part++;

		var bid = 'TemporaryStudioSet%StudioSetPart(Part' + part + ')';
		var MSB = parseInt(Parameter.paramSet[bid][6], 16);

		var blkSet = [];

		switch (MSB) {

		case 87:
			blkSet.push('TemporaryTonePart(' + part + ')%TemporaryPCMTone%PCMToneCommon');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporaryPCMTone%PCMToneCommonMFX');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporaryPCMTone%PCMTonePMT(PartialMixTable)');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporaryPCMTone%PCMTonePartial(Partial1)');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporaryPCMTone%PCMTonePartial(Partial2)');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporaryPCMTone%PCMTonePartial(Partial3)');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporaryPCMTone%PCMTonePartial(Partial4)');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporaryPCMTone%PCMToneCommon2');
			break;

		case 95:
			blkSet.push('TemporaryTonePart(' + part + ')%TemporarySynthTone%SynthToneCommon');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporarySynthTone%SynthToneMFX');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporarySynthTone%SynthTonePartial(1)');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporarySynthTone%SynthTonePartial(2)');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporarySynthTone%SynthTonePartial(3)');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporarySynthTone%SynthToneModify');
			break;

		case 89:
			blkSet.push('TemporaryTonePart(' + part + ')%TemporarySuperNATURALTone%SNToneCommon');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporarySuperNATURALTone%SNToneMFX');
			break;

		case 88:
			blkSet.push('TemporaryTonePart(' + part + ')%TemporaryDrumKit%DrumKitCommon');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporaryDrumKit%DrumKitMFX');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporaryDrumKit%DrumKitCommonComp/EQ');
			for (var key = 27; key <= 88; key++) {
				blkSet.push('TemporaryTonePart(' + part + ')' + '%TemporaryDrumKit%DrumKitNote(Key#' + key + ')');
			}
			break;

		case 86:
			blkSet.push('TemporaryTonePart(' + part + ')%TemporaryRhythmSet%RhythmSetCommon');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporaryRhythmSet%RhythmSetCommonMFX');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporaryRhythmSet%RhythmSetCommonComp/EQ');
			blkSet.push('TemporaryTonePart(' + part + ')%TemporaryRhythmSet%RhythmSetCommon2');
			for (var key = 21; key <= 108; key++) {
				blkSet.push('TemporaryTonePart(' + part + ')' + '%TemporaryRhythmSet%RhythmSetPartial(Key#' + key + ')');
			}
			break;
		}

		return blkSet;

	}
}
