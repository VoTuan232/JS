//
//	editor_setting.js
//
//	Copyright 2017 Roland Corporation. All rights reserved.
//

function EditorSetting1() { /* Setup/System */

	this.blockSet = [
		'Setup',
		'System%SystemCommon',
		'System%SystemController'
	];

	this.readStart = function(midi) {}
	this.readStop = function(midi) {}
	this.syncStart = function(midi) {}
	this.syncStop = function(midi) {}
	this.previewStart = function(midi, part) {}
	this.previewStop = function(midi) {}

	this.parts = 0;
}

function EditorSetting2() { /* Performance */

	this.blockSet = [];

	(function(blockSet) {
		blockSet.push('TemporaryPerformance%PerformCommon');
		blockSet.push('TemporaryPerformance%PerformCommonMFX1');
		blockSet.push('TemporaryPerformance%PerformCommonChorus');
		blockSet.push('TemporaryPerformance%PerformCommonReverb');
		blockSet.push('TemporaryPerformance%PerformCommonMFX2');
		blockSet.push('TemporaryPerformance%PerformCommonMFX3');
		for (var part = 1; part <= 16; part++) {
			blockSet.push('TemporaryPerformance%PerformMIDI(' + part + ')');
		}
		for (var part = 1; part <= 16; part++) {
			blockSet.push('TemporaryPerformance%PerformPart(' + part + ')');
		}
		for (var part = 1; part <= 16; part++) {
			blockSet.push('TemporaryPerformance%PerformZone(' + part + ')');
		}
		blockSet.push('TemporaryPerformance%PerformController');
	})(this.blockSet);

	this.parts = 16;
	this.partSet = function(part) {

		part = part + 1;

		var bid = 'TemporaryPerformance%PerformPart(' + part + ')';
		var MSB = parseInt(Parameter.paramSet[bid][4], 16);

		var blkSet = [];

		if (MSB) {
			if (MSB == 87 || MSB == 121) {
				blkSet.push('TemporaryPatch/DrumPerformance(' + part + ')%TemporaryPatch%PatchCommon');
				blkSet.push('TemporaryPatch/DrumPerformance(' + part + ')%TemporaryPatch%PatchCommonMFX');
				blkSet.push('TemporaryPatch/DrumPerformance(' + part + ')%TemporaryPatch%PatchCommonChorus');
				blkSet.push('TemporaryPatch/DrumPerformance(' + part + ')%TemporaryPatch%PatchCommonReverb');
				blkSet.push('TemporaryPatch/DrumPerformance(' + part + ')%TemporaryPatch%PatchTMT');
				blkSet.push('TemporaryPatch/DrumPerformance(' + part + ')%TemporaryPatch%PatchTone(1)');
				blkSet.push('TemporaryPatch/DrumPerformance(' + part + ')%TemporaryPatch%PatchTone(2)');
				blkSet.push('TemporaryPatch/DrumPerformance(' + part + ')%TemporaryPatch%PatchTone(3)');
				blkSet.push('TemporaryPatch/DrumPerformance(' + part + ')%TemporaryPatch%PatchTone(4)');
			} else if (MSB == 86 || MSB == 120) {
				blkSet.push('TemporaryPatch/DrumPerformance(' + part + ')%TemporaryDrum%DrumCommon');
				blkSet.push('TemporaryPatch/DrumPerformance(' + part + ')%TemporaryDrum%DrumCommonMFX');
				blkSet.push('TemporaryPatch/DrumPerformance(' + part + ')%TemporaryDrum%DrumCommonChorus');
				blkSet.push('TemporaryPatch/DrumPerformance(' + part + ')%TemporaryDrum%DrumCommonReverb');
				for (var key = 21; key <= 108; key++) {
					blkSet.push('TemporaryPatch/DrumPerformance(' + part + ')%TemporaryDrum%DrumTone(#' + key + ')');
				}
			}

		}
		return blkSet;
	}

	this.readStart = function(midi) {}
	this.readStop = function(midi) {}
	this.syncStart = function(midi) {}
	this.syncStop = function(midi) {}
	this.previewStart = function(midi, part) {
		midi.send('F04110' + ProductSetting.modelId + '120F0020000051F7');
		var chksum = 51 - (++part);
		midi.send('F04110' + ProductSetting.modelId + '120F002000' + hex2(part) + hex2(chksum) + 'F7');
	}
	this.previewStop = function(midi) {
		midi.send('F04110' + ProductSetting.modelId + '120F0020000051F7');
	}
}

function EditorSetting3() { /* Patch */

	this.blockSet = [];

	(function(blockSet) {
		blockSet.push('TemporaryPatch/DrumPatch(1)%TemporaryPatch%PatchCommon');
		blockSet.push('TemporaryPatch/DrumPatch(1)%TemporaryPatch%PatchCommonMFX');
		blockSet.push('TemporaryPatch/DrumPatch(1)%TemporaryPatch%PatchCommonChorus');
		blockSet.push('TemporaryPatch/DrumPatch(1)%TemporaryPatch%PatchCommonReverb');
		blockSet.push('TemporaryPatch/DrumPatch(1)%TemporaryPatch%PatchTMT');
		blockSet.push('TemporaryPatch/DrumPatch(1)%TemporaryPatch%PatchTone(1)');
		blockSet.push('TemporaryPatch/DrumPatch(1)%TemporaryPatch%PatchTone(2)');
		blockSet.push('TemporaryPatch/DrumPatch(1)%TemporaryPatch%PatchTone(3)');
		blockSet.push('TemporaryPatch/DrumPatch(1)%TemporaryPatch%PatchTone(4)');
	})(this.blockSet);

	this.parts = 0;

	this.readStart = function(midi) {
		midi.send('F04110' + ProductSetting.modelId + '120F0020000051F7');
		midi.send('F04110' + ProductSetting.modelId + '1201000000007FF7');
		midi.send('F04110' + ProductSetting.modelId + '120100000457000024F7');
	}
	this.readStop = function(midi) {}
	this.syncStart = function(midi) {
		midi.send('F04110' + ProductSetting.modelId + '120F0020000051F7');
		midi.send('F04110' + ProductSetting.modelId + '1201000000007FF7');
		midi.send('F04110' + ProductSetting.modelId + '120100000457000024F7');
	}
	this.syncStop = function(midi) {}
	this.previewStart = function(midi, part) {
		midi.send('F04110' + ProductSetting.modelId + '120F0020000150F7');
	}
	this.previewStop = function(midi) {
		midi.send('F04110' + ProductSetting.modelId + '120F0020000051F7');
	}
}

function EditorSetting4() { /* Drum Kit */

	this.blockSet = [];

	(function(blockSet) {
		blockSet.push('TemporaryPatch/DrumPatch(1)%TemporaryDrum%DrumCommon');
		blockSet.push('TemporaryPatch/DrumPatch(1)%TemporaryDrum%DrumCommonMFX');
		blockSet.push('TemporaryPatch/DrumPatch(1)%TemporaryDrum%DrumCommonChorus');
		blockSet.push('TemporaryPatch/DrumPatch(1)%TemporaryDrum%DrumCommonReverb');
		for (var key = 21; key <= 108; key++) {
			blockSet.push('TemporaryPatch/DrumPatch(1)%TemporaryDrum%DrumTone(#' + key + ')');
		}
	})(this.blockSet);

	this.parts = 0;

	this.readStart = function(midi) {
		midi.send('F04110' + ProductSetting.modelId + '120F0020000051F7');
		midi.send('F04110' + ProductSetting.modelId + '1201000000007FF7');
		midi.send('F04110' + ProductSetting.modelId + '120100000456000025F7');
	}
	this.readStop = function(midi) {}
	this.syncStart = function(midi) {
		midi.send('F04110' + ProductSetting.modelId + '120F0020000051F7');
		midi.send('F04110' + ProductSetting.modelId + '1201000000007FF7');
		midi.send('F04110' + ProductSetting.modelId + '120100000456000025F7');
	}
	this.syncStop = function(midi) {}
	this.previewStart = function(midi, part) {
		midi.send('F04110' + ProductSetting.modelId + '120F0020000150F7');
	}
	this.previewStop = function(midi) {
		midi.send('F04110' + ProductSetting.modelId + '120F0020000051F7');
	}
}
