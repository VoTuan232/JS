//
// address_map.js
//
// Copyright 2016 Roland Corporation. All rights reserved.
//

function AddressMap() {

	/* parameter definitions  */

	var FC = [ // Studio Set Common
		{ addr: 0x0000, size: 16	, ofs: 0	, min: 32	, max: 127	, init: 'InitTone        '	,	name: 'Studio Set Name' },
		{ addr: 0x0010, size: INTEGER1x6, ofs: 0	, min: 0	, max: 127	, init: 100	,	name: 'Studio Set Level' },
		{ addr: 0x0011, size: INTEGER1x6, ofs: 0	, min: 0	, max: 16	, init: 16	,	name: 'MFX1 Control Channel' },
		{ addr: 0x0012, size: INTEGER1x6, ofs: 0	, min: 0	, max: 16	, init: 16	,	name: 'MFX2 Control Channel' },
		{ addr: 0x0013, size: INTEGER1x6, ofs: 0	, min: 0	, max: 16	, init: 16	,	name: 'MFX3 Control Channel' },
		{ addr: 0x0014, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'MFX Control Src1' },
		{ addr: 0x0015, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'MFX Control Src2' },
		{ addr: 0x0016, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'MFX Control Src3' },
		{ addr: 0x0017, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'MFX Control Src4' },
		{ addr: 0x0018, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Voice Reserve 1 ' },
		{ addr: 0x0019, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Voice Reserve 2 ' },
		{ addr: 0x001A, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Voice Reserve 3 ' },
		{ addr: 0x001B, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Voice Reserve 4 ' },
		{ addr: 0x001C, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Voice Reserve 5 ' },
		{ addr: 0x001D, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Voice Reserve 6 ' },
		{ addr: 0x001E, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Voice Reserve 7 ' },
		{ addr: 0x001F, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Voice Reserve 8 ' },
		{ addr: 0x0020, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Voice Reserve 9 ' },
		{ addr: 0x0021, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Voice Reserve 10' },
		{ addr: 0x0022, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Voice Reserve 11' },
		{ addr: 0x0023, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Voice Reserve 12' },
		{ addr: 0x0024, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Voice Reserve 13' },
		{ addr: 0x0025, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Voice Reserve 14' },
		{ addr: 0x0026, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Voice Reserve 15' },
		{ addr: 0x0027, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Voice Reserve 16' },
		{ addr: 0x0038, size: INTEGER1x5, ofs: 0	, min: 0	, max: 16	, init: 0	,	name: 'MFX1 Source' },
		{ addr: 0x0039, size: INTEGER1x5, ofs: 0	, min: 0	, max: 16	, init: 0	,	name: 'MFX2 Source' },
		{ addr: 0x003A, size: INTEGER1x5, ofs: 0	, min: 0	, max: 16	, init: 0	,	name: 'Chorus Source' },
		{ addr: 0x003B, size: INTEGER1x5, ofs: 0	, min: 0	, max: 16	, init: 0	,	name: 'Reverb Source' },
		{ addr: 0x003C, size: INTEGER1x1, ofs: 0	, min: 0	, max: 16	, init: 1	,	name: 'MFX1 Switch' },
		{ addr: 0x003D, size: INTEGER1x1, ofs: 0	, min: 0	, max: 16	, init: 1	,	name: 'MFX2 Switch' },
		{ addr: 0x003E, size: INTEGER1x1, ofs: 0	, min: 0	, max: 16	, init: 1	,	name: 'Chorus Switch' },
		{ addr: 0x003F, size: INTEGER1x1, ofs: 0	, min: 0	, max: 16	, init: 1	,	name: 'Reverb Switch' },
		{ addr: 0x0040, size: INTEGER1x2, ofs: 0	, min: 0	, max: 2	, init: 1	,	name: 'MFX Structure' },
		{ addr: 0x0041, size: INTEGER1x7, ofs: 59	, min: 0	, max: 11	, init: 5	,	name: 'Transpose Value' },
		{ addr: 0x0042, size: INTEGER1x7, ofs: 61	, min: 0	, max: 6	, init: 3	,	name: 'Octave Shift' },
		{ addr: 0x0043, size: INTEGER1x5, ofs: 0	, min: 0	, max: 31	, init: 1	,	name: 'MFX1 Cotrol Parameter'},
		{ addr: 0x0044, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX1 Control Min Value' },
		{ addr: 0x0048, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 127	,	name: 'MFX1 Control Max Value' },
		{ addr: 0x004C, size: INTEGER1x5, ofs: 0	, min: 0	, max: 31	, init: 0	,	name: 'MFX2 Cotrol Parameter'},
		{ addr: 0x004D, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX2 Control Min Value' },
		{ addr: 0x0051, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX2 Control Max Value' },
		{ addr: 0x0055, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 11	,	name: 'Breath1 Control Assign' },
		{ addr: 0x0056, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Breath1 Control Min Value' },
		{ addr: 0x0057, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'Breath1 Control Max Value' },
		{ addr: 0x0058, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Breath1 Control Toggle' },
		{ addr: 0x0059, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Breath2 Control Assign' },
		{ addr: 0x005A, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Breath2 Control Min Value' },
		{ addr: 0x005B, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'Breath2 Control Max Value' },
		{ addr: 0x005C, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Breath2 Control Toggle' },
		{ addr: 0x005D, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Bite1 Control Assign' },
		{ addr: 0x005E, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Bite1 Control Min Value' },
		{ addr: 0x005F, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'Bite1 Control Max Value' },
		{ addr: 0x0060, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Bite1 Control Toggle' },
		{ addr: 0x0061, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Bite2 Control Assign' },
		{ addr: 0x0062, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Bite2 Control Min Value' },
		{ addr: 0x0063, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'Bite2 Control Max Value' },
		{ addr: 0x0064, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Bite2 Control Toggle' },
		{ addr: 0x0065, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 96	,	name: 'Up1 Control Assign' },
		{ addr: 0x0066, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 64	,	name: 'Up1 Control Min Value' },
		{ addr: 0x0067, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'Up1 Control Max Value' },
		{ addr: 0x0068, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Up1 Control Toggle' },
		{ addr: 0x0069, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Up2 Control Assign' },
		{ addr: 0x006A, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Up2 Control Min Value' },
		{ addr: 0x006B, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'Up2 Control Max Value' },
		{ addr: 0x006C, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Up2 Control Toggle' },
		{ addr: 0x006D, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 96	,	name: 'Down1 Control Assign' },
		{ addr: 0x006E, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 64	,	name: 'Down1 Control Min Value' },
		{ addr: 0x006F, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Down1 Control Max Value' },
		{ addr: 0x0070, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Down1 Control Toggle' },
		{ addr: 0x0071, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Down2 Control Assign' },
		{ addr: 0x0072, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Down2 Control Min Value' },
		{ addr: 0x0073, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'Down2 Control Max Value' },
		{ addr: 0x0074, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Down2 Control Toggle' },
		{ addr: 0x0075, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Left1 Control Assign' },
		{ addr: 0x0076, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Left1 Control Min Value' },
		{ addr: 0x0077, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'Left1 Control Max Value' },
		{ addr: 0x0078, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Left1 Control Toggle' },
		{ addr: 0x0079, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Left2 Control Assign' },
		{ addr: 0x007A, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Left2 Control Min Value' },
		{ addr: 0x007B, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'Left2 Control Max Value' },
		{ addr: 0x007C, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Left2 Control Toggle' },
		{ addr: 0x007D, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Right1 Control Assign' },
		{ addr: 0x007E, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Right1 Control Min Value' },
		{ addr: 0x007F, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'Right1 Control Max Value' },
		{ addr: 0x0100, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Right1 Control Toggle' },
		{ addr: 0x0101, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Right2 Control Assign' },
		{ addr: 0x0102, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Right2 Control Min Value' },
		{ addr: 0x0103, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'Right2 Control Max Value' },
		{ addr: 0x0104, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Right2 Control Toggle' },
		{ addr: 0x0105, size: INTEGER1x2, ofs: 0	, min: 0	, max: 2	, init: 1	,	name: 'Octave Key Mode' },
		{ addr: 0x0106, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Hold Switch' },
		{ addr: 0x0107, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Vibrato Upper Max Value' },
		{ addr: 0x0108, size: INTEGER1x7, ofs: 0	, min: 0	, max: 64	, init: 0	,	name: 'Vibrato Lower Max Value' },
		{ addr: 0x0109, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Velocity Min Value' },
		{ addr: 0x010A, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'Velocity Max Value' },
		{ addr: 0x010B, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Stream Mode' },
		{ addr: 0x010C, size: INTEGER1x7, ofs: 0	, min: 0	, max: 97	, init: 1	,	name: 'Tone Control 1 Source' },
		{ addr: 0x010D, size: INTEGER1x7, ofs: 0	, min: 0	, max: 97	, init: 97	,	name: 'Tone Control 2 Source' },
		{ addr: 0x010E, size: INTEGER1x7, ofs: 0	, min: 0	, max: 97	, init: 2	,	name: 'Tone Control 3 Source' },
		{ addr: 0x010F, size: INTEGER1x7, ofs: 0	, min: 0	, max: 97	, init: 4	,	name: 'Tone Control 4 Source' },
		{ addr: 0x0110, size: INTEGER2x4, ofs: 0	, min: 20	, max: 250	, init: 120	,	name: 'Studio Set Tempo' },
		{ addr: 0x0112, size: INTEGER1x5, ofs: 0	, min: 0	, max: 16	, init: 0	,	name: 'Solo Part' }
	];

	var FF = [ // Studio Set Common MFX
		{ addr: 0x0000, size: INTEGER1x7, ofs: 0	, min: 0	, max: 79	, init: 0	,	name: 'MFX Type' },
		{ addr: 0x0001, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'MFX Dry Send Level' },
		{ addr: 0x0002, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'MFX Chours Send Level' },
		{ addr: 0x0003, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 64	,	name: 'MFX Reverb Send Level' },
		{ addr: 0x0004, size: INTEGER1x2, ofs: 0	, min: 0	, max: 3	, init: 0	,	name: 'MFX Output Assign ' },
		{ addr: 0x0005, size: INTEGER1x7, ofs: 0	, min: 0	, max: 101	, init: 0	,	name: 'MFX Control 1 Source' },
		{ addr: 0x0006, size: INTEGER1x7, ofs: 64	, min: -63	, max: 63	, init: 0	,	name: 'MFX Control 1 Sens' },
		{ addr: 0x0007, size: INTEGER1x7, ofs: 0	, min: 0	, max: 101	, init: 0	,	name: 'MFX Control 2 Source' },
		{ addr: 0x0008, size: INTEGER1x7, ofs: 64	, min: -63	, max: 63	, init: 0	,	name: 'MFX Control 2 Sens' },
		{ addr: 0x0009, size: INTEGER1x7, ofs: 0	, min: 0	, max: 101	, init: 0	,	name: 'MFX Control 3 Source' },
		{ addr: 0x000A, size: INTEGER1x7, ofs: 64	, min: -63	, max: 63	, init: 0	,	name: 'MFX Control 3 Sens' },
		{ addr: 0x000B, size: INTEGER1x7, ofs: 0	, min: 0	, max: 101	, init: 0	,	name: 'MFX Control 4 Source' },
		{ addr: 0x000C, size: INTEGER1x7, ofs: 64	, min: -63	, max: 63	, init: 0	,	name: 'MFX Control 4 Sens' },
		{ addr: 0x000D, size: INTEGER1x7, ofs: 0	, min: 0	, max: 16	, init: 0	,	name: 'MFX Control Assign 1' },
		{ addr: 0x000E, size: INTEGER1x7, ofs: 0	, min: 0	, max: 16	, init: 0	,	name: 'MFX Control Assign 2' },
		{ addr: 0x000F, size: INTEGER1x7, ofs: 0	, min: 0	, max: 16	, init: 0	,	name: 'MFX Control Assign 3' },
		{ addr: 0x0010, size: INTEGER1x7, ofs: 0	, min: 0	, max: 16	, init: 0	,	name: 'MFX Control Assign 4' },
		{ addr: 0x0011, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 1 ' },
		{ addr: 0x0015, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 2 ' },
		{ addr: 0x0019, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 3 ' },
		{ addr: 0x001D, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 4 ' },
		{ addr: 0x0021, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 5 ' },
		{ addr: 0x0025, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 6 ' },
		{ addr: 0x0029, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 7 ' },
		{ addr: 0x002D, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 8 ' },
		{ addr: 0x0031, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 9 ' },
		{ addr: 0x0035, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 10' },
		{ addr: 0x0039, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 11' },
		{ addr: 0x003D, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 12' },
		{ addr: 0x0041, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 13' },
		{ addr: 0x0045, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 14' },
		{ addr: 0x0049, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 15' },
		{ addr: 0x004D, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 16' },
		{ addr: 0x0051, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 17' },
		{ addr: 0x0055, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 18' },
		{ addr: 0x0059, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 19' },
		{ addr: 0x005D, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 20' },
		{ addr: 0x0061, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 21' },
		{ addr: 0x0065, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 22' },
		{ addr: 0x0069, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 23' },
		{ addr: 0x006D, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 24' },
		{ addr: 0x0071, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 25' },
		{ addr: 0x0075, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 26' },
		{ addr: 0x0079, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 27' },
		{ addr: 0x007D, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 28' },
		{ addr: 0x0101, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 29' },
		{ addr: 0x0105, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 30' },
		{ addr: 0x0109, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 31' },
		{ addr: 0x010D, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'MFX Parameter 32' }
	];

	var FH = [ // Studio Set Common Chorus
		{ addr: 0x0000, size: INTEGER1x4, ofs: 0	, min: 0	, max: 3	, init: 1	,	name: 'Chorus Type' },
		{ addr: 0x0001, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'Chorus Level' },
		{ addr: 0x0002, size: INTEGER1x2, ofs: 0	, min: 0	, max: 3	, init: 0	,	name: 'Chorus Output Assign ' },
		{ addr: 0x0003, size: INTEGER1x2, ofs: 0	, min: 0	, max: 2	, init: 0	,	name: 'Chorus Output Select ' },
		{ addr: 0x0004, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 2	,	name: 'Chorus Parameter 1 ' },
		{ addr: 0x0008, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 6	,	name: 'Chorus Parameter 2 ' },
		{ addr: 0x000C, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 20	,	name: 'Chorus Parameter 3 ' },
		{ addr: 0x0010, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 1	,	name: 'Chorus Parameter 4 ' },
		{ addr: 0x0014, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 10	,	name: 'Chorus Parameter 5 ' },
		{ addr: 0x0018, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 18	,	name: 'Chorus Parameter 6 ' },
		{ addr: 0x001C, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 30	,	name: 'Chorus Parameter 7 ' },
		{ addr: 0x0020, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 90	,	name: 'Chorus Parameter 8 ' },
		{ addr: 0x0024, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Chorus Parameter 9 ' },
		{ addr: 0x0028, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Chorus Parameter 10' },
		{ addr: 0x002C, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Chorus Parameter 11' },
		{ addr: 0x0030, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Chorus Parameter 12' },
		{ addr: 0x0034, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Chorus Parameter 13' },
		{ addr: 0x0038, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Chorus Parameter 14' },
		{ addr: 0x003C, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Chorus Parameter 15' },
		{ addr: 0x0040, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Chorus Parameter 16' },
		{ addr: 0x0044, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Chorus Parameter 17' },
		{ addr: 0x0048, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Chorus Parameter 18' },
		{ addr: 0x004C, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Chorus Parameter 19' },
		{ addr: 0x0050, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Chorus Parameter 20' }
	];

	var FV = [ // Studio Set Common Reverb
		{ addr: 0x0000, size: INTEGER1x4, ofs: 0	, min: 0	, max: 5	, init: 1	,	name: 'Reverb Type' },
		{ addr: 0x0001, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'Reverb Level' },
		{ addr: 0x0002, size: INTEGER1x2, ofs: 0	, min: 0	, max: 3	, init: 0	,	name: 'Reverb Output Assign' },
		{ addr: 0x0003, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 3	,	name: 'Reverb Parameter 1 ' },
		{ addr: 0x0007, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 84	,	name: 'Reverb Parameter 2 ' },
		{ addr: 0x000B, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 16	,	name: 'Reverb Parameter 3 ' },
		{ addr: 0x000F, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 4 ' },
		{ addr: 0x0013, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 5 ' },
		{ addr: 0x0017, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 6 ' },
		{ addr: 0x001B, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 7 ' },
		{ addr: 0x001F, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 8 ' },
		{ addr: 0x0023, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 9 ' },
		{ addr: 0x0027, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 10' },
		{ addr: 0x002B, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 11' },
		{ addr: 0x002F, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 12' },
		{ addr: 0x0033, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 13' },
		{ addr: 0x0037, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 14' },
		{ addr: 0x003B, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 15' },
		{ addr: 0x003F, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 16' },
		{ addr: 0x0043, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 17' },
		{ addr: 0x0047, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 18' },
		{ addr: 0x004B, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 19' },
		{ addr: 0x004F, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 20' },
		{ addr: 0x0053, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 21' },
		{ addr: 0x0057, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 22' },
		{ addr: 0x005B, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 23' },
		{ addr: 0x005F, size: INTEGER4x4, ofs: 32768	, min: -20000	, max: 20000	, init: 0	,	name: 'Reverb Parameter 24' }
	];

	var FM = [ // Studio Set MIDI
		{ addr: 0x0000, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Phase Lock' }
	];

	var FP = [ // Studio Set Part
		{ addr: 0x0000, size: INTEGER1x4, ofs: 0	, min: 0	, max: 15	, init: 0	,	name: 'Receive Channel' },
		{ addr: 0x0001, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'Part Switch' },
		{ addr: 0x0002, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'Receive Src1' },
		{ addr: 0x0003, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'Receive Src2' },
		{ addr: 0x0004, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'Receive Src3' },
		{ addr: 0x0005, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'Receive Src4' },
		{ addr: 0x0006, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 87	,	name: 'Tone Bank Select MSB (CC# 0)' },
		{ addr: 0x0007, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 64	,	name: 'Tone Bank Select LSB (CC# 32)' },
		{ addr: 0x0008, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 27	,	name: 'Tone Program Number (PC)' },
		{ addr: 0x0009, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 100	,	name: 'Part Level (CC# 7)' },
		{ addr: 0x000A, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 64	,	name: 'Part Pan (CC# 10)' },
		{ addr: 0x000B, size: INTEGER1x7, ofs: 64	, min: -48	, max: 48	, init: 0	,	name: 'Part Coarse Tune (RPN# 2)' },
		{ addr: 0x000C, size: INTEGER1x7, ofs: 64	, min: -50	, max: 50	, init: 0	,	name: 'Part Fine Tune (RPN# 1)' },
		{ addr: 0x000D, size: INTEGER1x2, ofs: 0	, min: 0	, max: 2	, init: 2	,	name: 'Part Mono/Poly (MONO ON/POLY ON)' },
		{ addr: 0x000E, size: INTEGER1x2, ofs: 0	, min: 0	, max: 2	, init: 2	,	name: 'Part Legato Switch (CC# 68)' },
		{ addr: 0x000F, size: INTEGER1x5, ofs: 0	, min: 0	, max: 25	, init: 4	,	name: 'Part Pitch Bend Range (RPN# 0)' },
		{ addr: 0x0010, size: INTEGER1x2, ofs: 0	, min: 0	, max: 2	, init: 2	,	name: 'Part Portamento Switch (CC# 65)' },
		{ addr: 0x0011, size: INTEGER2x4, ofs: 0	, min: 0	, max: 128	, init: 128	,	name: 'Part Portamento Time (CC# 5)' },
		{ addr: 0x0013, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Cutoff Offset (CC# 74)' },
		{ addr: 0x0014, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Resonance Offset (CC# 71)' },
		{ addr: 0x0015, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Attack Time Offset (CC# 73)' },
		{ addr: 0x0016, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Decay Time Offset (CC# 75)' },
		{ addr: 0x0017, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Release Time Offset (CC# 72)' },
		{ addr: 0x0018, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Vibrato Rate (CC# 76)' },
		{ addr: 0x0019, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Vibrato Depth (CC# 77)' },
		{ addr: 0x001A, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Vibrato Delay (CC# 78)' },
		{ addr: 0x001B, size: INTEGER1x3, ofs: 61	, min: 0	, max: 6	, init: 3	,	name: 'Part Octave Shift' },
		{ addr: 0x001C, size: INTEGER1x7, ofs: 64	, min: -63	, max: 63	, init: 0	,	name: 'Part Velocity Sens Offset' },
		{ addr: 0x001D, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Keyboard Range Lower' },
		{ addr: 0x001E, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'Keyboard Range Upper' },
		{ addr: 0x001F, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Keyboard Fade Width Lower' },
		{ addr: 0x0020, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Keyboard Fade Width Upper' },
		{ addr: 0x0021, size: INTEGER1x7, ofs: 0	, min: 1	, max: 127	, init: 1	,	name: 'Velocity Range Lower' },
		{ addr: 0x0022, size: INTEGER1x7, ofs: 0	, min: 1	, max: 127	, init: 127	,	name: 'Velocity Range Upper' },
		{ addr: 0x0023, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Velocity Fade Width Lower' },
		{ addr: 0x0024, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Velocity Fade Width Upper' },
		{ addr: 0x0025, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Mute Switch' },
		{ addr: 0x0026, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 127	,	name: 'Part Dry Send Level' },
		{ addr: 0x0027, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 0	,	name: 'Part Chorus Send Level (CC# 93)' },
		{ addr: 0x0028, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 20	,	name: 'Part Reverb Send Level (CC# 91)' },
		{ addr: 0x0029, size: INTEGER1x4, ofs: 0	, min: 0	, max: 11	, init: 0	,	name: 'Part Output Assign' },
		{ addr: 0x002A, size: INTEGER1x2, ofs: 0	, min: 0	, max: 1	, init: 0	,	name: 'Part Output MFX Select' },
		{ addr: 0x002B, size: INTEGER1x7, ofs: 0	, min: 0	, max: 8	, init: 1	,	name: 'Part Scale Tune Type' },
		{ addr: 0x002C, size: INTEGER1x7, ofs: 0	, min: 0	, max: 11	, init: 0	,	name: 'Part Scale Tune Key' },
		{ addr: 0x002D, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Scale Tune for C' },
		{ addr: 0x002E, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Scale Tune for C#' },
		{ addr: 0x002F, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Scale Tune for D' },
		{ addr: 0x0030, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Scale Tune for D#' },
		{ addr: 0x0031, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Scale Tune for E' },
		{ addr: 0x0032, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Scale Tune for F' },
		{ addr: 0x0033, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Scale Tune for F#' },
		{ addr: 0x0034, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Scale Tune for G' },
		{ addr: 0x0035, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Scale Tune for G#' },
		{ addr: 0x0036, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Scale Tune for A' },
		{ addr: 0x0037, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Scale Tune for A#' },
		{ addr: 0x0038, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Part Scale Tune for B' },
		{ addr: 0x0039, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'Receive Program Change' },
		{ addr: 0x003A, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'Receive Bank Select' },
		{ addr: 0x003B, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'Receive Pitch Bend' },
		{ addr: 0x003C, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'Receive Polyphonic Key Pressure' },
		{ addr: 0x003D, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'Receive Channel Pressure' },
		{ addr: 0x003E, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'Receive Modulation' },
		{ addr: 0x003F, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'Receive Volume' },
		{ addr: 0x0040, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'Receive Pan' },
		{ addr: 0x0041, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'Receive Expression' },
		{ addr: 0x0042, size: INTEGER1x1, ofs: 0	, min: 0	, max: 1	, init: 1	,	name: 'Receive Hold-1' },
		{ addr: 0x0043, size: INTEGER1x3, ofs: 0	, min: 0	, max: 4	, init: 0	,	name: 'Velocity Curve Type' },
		{ addr: 0x0044, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 0	,	name: 'Motional Surround X-Pos' },
		{ addr: 0x0046, size: INTEGER1x7, ofs: 64	, min: -64	, max: 63	, init: 10	,	name: 'Motional Surround Y-Pos' },
		{ addr: 0x0048, size: INTEGER1x6, ofs: 0	, min: 0	, max: 32	, init: 10	,	name: 'Motional Surround Width' },
		{ addr: 0x0049, size: INTEGER1x7, ofs: 0	, min: 0	, max: 127	, init: 40	,	name: 'Motional Surround RevSend Level' }
	];

	/* block definitions  */

	var PRF = [ // Studio Set
		{ addr: 0x000000, size: 0, child: FC,	name: 'StudioSetCommon' },
		{ addr: 0x000200, size: 0, child: FF,	name: 'StudioSetCommonMFX(MFX1)' },
		{ addr: 0x000400, size: 0, child: FH,	name: 'StudioSetCommonChorus' },
		{ addr: 0x000600, size: 0, child: FV,	name: 'StudioSetCommonReverb' },
		{ addr: 0x000800, size: 0, child: FF,	name: 'StudioSetCommonMFX(MFX2)' },
		{ addr: 0x002000, size: 0, child: FP,	name: 'StudioSetPart(Part1)' },
		{ addr: 0x002100, size: 0, child: FP,	name: 'StudioSetPart(Part2)' },
		{ addr: 0x002200, size: 0, child: FP,	name: 'StudioSetPart(Part3)' },
		{ addr: 0x002300, size: 0, child: FP,	name: 'StudioSetPart(Part4)' },
	];

	this.root = [
		{ addr: 0x18000000, size: 0, child: PRF, name: 'TemporaryStudioSet' },
	];

	/* construction */
	(function(root){

		/* calucrate size */
		(function(a) {
			for (var n = a.length - 1; n >= 0; n--) {
				var b = a[n];
				if ('child' in b) {
					b.size = arguments.callee(b.child);
				} else {
					var bytes = 0;
					switch (b.size) {
						case INTEGER1x1: case INTEGER1x2: case INTEGER1x3: case INTEGER1x4:
						case INTEGER1x5: case INTEGER1x6: case INTEGER1x7:
							bytes = 1; break;
						case INTEGER2x4:
							bytes = 2; break;
						case INTEGER4x4:
							bytes = 4; break;
						default:
							bytes = b.size; break;
					}
					return b.addr + bytes;
				}
			}
			return 0;
		})(root);

		/* all addr and size is nibbled. */
		(function(a) {
			for (var n = 0, max = a.length; n < max; n++) {
				var b = a[n];
				if (!('nibbled' in b)) {
					b.nibbled = true;
					b.addr = nibble(b.addr);
					b.size = (0 < b.size && b.size < INTEGER1x1) ? nibble(b.size) : b.size;
					if ('child' in b) arguments.callee(b.child);
				}
			}
		})(root);

		for (var i = 0; i < 100; i++) {
			var b = {};
			b.name  = 'UserStudioSet(' + (i + 1) + ')';
			b.addr  = nibble(0x2F000000) + (i * nibble(0x10000));
			b.size  = 0;
			b.child = PRF;
			root.push(b);
		}

	})(this.root);

	this.layout = [ /* for layout tool */
		{ addr: 0, size: 0, child: PRF, name: 'TemporaryStudioSet' },
	];
}
